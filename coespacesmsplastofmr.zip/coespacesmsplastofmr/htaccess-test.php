htaccess-test.php<?php
echo "URL Rewriting Works!";
?>